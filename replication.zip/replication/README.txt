// Author: Igor Francetic
// Date: 24/10/2024

////////////////////////////////////////////////////////////////////////
// INSTRUCTIONS TO USE THE REPLICATION PACKAGE
////////////////////////////////////////////////////////////////////////

The folder structures and files in this replication package will allow you
to replicate the tables and figures in the paper using the statistical software
Stata, version 18.

The main do-file to use is named "analysis.do". That will call the auxiliary files 
"workforce" and "capital" to generate variables from the raw data files stored 
in the "datain" folder.

To use the package there are only three steps to follow:
1. Download and unzip the package, and keep all files and folder in the same subfolder
2. Downlad the zip archive containing the NHS England regional "Shapefile" boundaries 
into the "maps" folder from the following link:
https://www.data.gov.uk/dataset/3664f211-2655-45e1-9a9b-e21d5b76ba6c/nhs-england-regions-january-2024-en-bgc
3. Open the "analysis.do" file and run it on your computer